-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 23, 2021 at 12:01 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projekat`
--

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `session_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `posts_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `carts`
--

INSERT INTO `carts` (`id`, `session_id`, `user_id`, `posts_id`, `quantity`, `created_at`, `updated_at`) VALUES
(1, 'L4Vb5YvtfNm5ahzDQWPxgu5McpNmpasD2UPNrW2k', 6, 2, 1, '2021-06-22 18:18:21', '2021-06-22 18:18:21'),
(4, 'GGXJua8OELD3TJ7sSPebF5SE6EehzgzL8hHhFZCV', 4, 2, 1, '2021-06-22 18:21:03', '2021-06-22 18:21:03'),
(6, 'KItIgVASFfVJRCE4G7WhjUcGOcN0HslWwFbM7pbh', 5, 19, 1, '2021-06-22 18:25:26', '2021-06-22 18:25:26'),
(7, 'AIToiK9WJtLxkJdEYktmyQXVC4vAK5nyJlA1zSGR', 5, 3, 5, '2021-06-22 18:49:52', '2021-06-22 18:49:52'),
(11, '0LRmMI7BYxcu4LsPCeadJesqxgAj2SzhhRGoiUg5', 6, 4, 2, '2021-06-22 18:52:02', '2021-06-22 18:52:02'),
(12, 'QM6PbCIDRY3kYKytv5nlYKoRo86ZYNg3dNwZS9tb', 7, 4, 1, '2021-06-22 18:55:06', '2021-06-22 18:55:06'),
(14, 'QM6PbCIDRY3kYKytv5nlYKoRo86ZYNg3dNwZS9tb', 7, 21, 2, '2021-06-22 18:55:47', '2021-06-22 18:55:47'),
(16, 'ngZthP2iojyvLy5uS9NSw5ZTa5EcTBeJ6m4Gb1mB', 8, 1, 1, '2021-06-22 19:02:56', '2021-06-22 19:02:56'),
(17, 'ngZthP2iojyvLy5uS9NSw5ZTa5EcTBeJ6m4Gb1mB', 8, 5, 2, '2021-06-22 19:03:31', '2021-06-22 19:03:31'),
(21, 'WSn4MSCR6lfNrLGkhswJD8SkUWrxxNYQSNNQbyl1', 9, 8, 1, '2021-06-22 19:05:01', '2021-06-22 19:05:01'),
(23, 'p98KpXZ354Va7vEyowYv12wt5zyBfSnYNtwP7nRs', 10, 28, 1, '2021-06-22 19:06:14', '2021-06-22 19:06:14');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `comments` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `user_id`, `post_id`, `comments`, `created_at`, `updated_at`) VALUES
(1, 4, 2, 'Komentar', '2021-06-22 18:14:15', '2021-06-22 18:14:15'),
(3, 4, 4, 'Odlicna knjiga', '2021-06-22 18:21:39', '2021-06-22 18:21:39'),
(4, 5, 29, 'Super knjiga', '2021-06-22 18:24:41', '2021-06-22 18:24:41'),
(6, 5, 30, 'Odlicna knjiga', '2021-06-22 18:37:54', '2021-06-22 18:37:54'),
(7, 5, 4, 'DOBRAAA', '2021-06-22 18:38:08', '2021-06-22 18:38:08'),
(8, 5, 3, 'Jako losa knjiga, ne bih je preporucio', '2021-06-22 18:38:45', '2021-06-22 18:38:45'),
(9, 6, 6, 'Ne bih je preporucio', '2021-06-22 18:39:06', '2021-06-22 18:39:06'),
(10, 6, 4, 'Nije neka', '2021-06-22 18:39:30', '2021-06-22 18:39:30'),
(11, 6, 6, 'Bezveze', '2021-06-22 18:39:40', '2021-06-22 18:39:40'),
(12, 6, 8, 'Dobra', '2021-06-22 18:51:06', '2021-06-22 18:51:06'),
(13, 6, 23, 'komentar', '2021-06-22 18:51:36', '2021-06-22 18:51:36'),
(14, 7, 2, 'Losa knjiga', '2021-06-22 18:54:51', '2021-06-22 18:54:51'),
(15, 7, 4, 'Dobra knjiga', '2021-06-22 18:55:05', '2021-06-22 18:55:05'),
(16, 7, 21, 'Hvala na ukazanom poverenju', '2021-06-22 18:55:45', '2021-06-22 18:55:45'),
(17, 8, 7, 'Super knjiga', '2021-06-22 19:02:38', '2021-06-22 19:02:38'),
(18, 8, 1, 'Bas dobra knjiga', '2021-06-22 19:02:53', '2021-06-22 19:02:53'),
(19, 8, 5, 'Odlicnaaaaa', '2021-06-22 19:03:24', '2021-06-22 19:03:24'),
(20, 9, 1, 'Nije neka', '2021-06-22 19:04:09', '2021-06-22 19:04:09'),
(21, 9, 3, 'Ok, ali nista posebno.', '2021-06-22 19:04:29', '2021-06-22 19:04:29'),
(22, 9, 15, 'OK', '2021-06-22 19:04:51', '2021-06-22 19:04:51'),
(23, 10, 8, 'Pristojna ali nista spec', '2021-06-22 19:05:51', '2021-06-22 19:05:51'),
(24, 10, 28, 'BAS DOBRAAA', '2021-06-22 19:06:13', '2021-06-22 19:06:13'),
(25, 10, 7, 'Ok', '2021-06-22 19:08:13', '2021-06-22 19:08:13'),
(26, 10, 4, 'Pristojna', '2021-06-22 19:08:27', '2021-06-22 19:08:27');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `messages` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `name`, `email`, `subject`, `messages`, `created_at`, `updated_at`) VALUES
(1, 'Nemanja Petrovic', 'dsda@fsd.rs', 'Poruka', 'Poruka', '2021-06-22 18:26:57', '2021-06-22 18:26:57'),
(2, 'Petar', 'petar@petar.rs', 'Poruka', 'poruka.......', '2021-06-22 18:27:46', '2021-06-22 18:27:46'),
(3, 'Mika Mikic', 'mika@mika.rs', 'pitanje', 'Gde se tacno nalazite', '2021-06-22 18:34:14', '2021-06-22 18:34:14'),
(5, 'Nikola', '12@123.rs', 'Stanje knjiga', 'Kakvo je stanje knjiga', '2021-06-22 18:57:04', '2021-06-22 18:57:04'),
(6, 'Matej', 'matej@sad.rs', 'Kvalitet', 'Kakav je kvalitet knjiga', '2021-06-22 18:58:31', '2021-06-22 18:58:31'),
(7, 'Mira', 'mira@mira.rs', 'Popust', 'Da li mozemo da dobijemo popust na vecu kolicinu kupljenih knjiga', '2021-06-22 18:59:27', '2021-06-22 18:59:27'),
(8, 'Marko', 'marko@marko.rs', 'Komentar na knjige', 'Hvala za sve, odlicne su knjige', '2021-06-22 19:00:13', '2021-06-22 19:00:13'),
(9, 'Sara', 'sara@sara.rs', 'Saradnja', 'Hvala na saradnji, super ste !!!', '2021-06-22 19:00:46', '2021-06-22 19:00:46'),
(10, 'Milos Mikic', 'milos@mikic.rs', 'Knjiga', 'Knjige su super', '2021-06-22 19:01:14', '2021-06-22 19:01:14'),
(11, 'Marijana', 'mar@mar.rs', 'Saradnja', 'Hvala na saradnji', '2021-06-22 19:08:06', '2021-06-22 19:08:06');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(67, '2014_10_12_000000_create_users_table', 2),
(68, '2014_10_12_100000_create_password_resets_table', 2),
(69, '2014_10_12_200000_add_two_factor_columns_to_users_table', 2),
(70, '2019_08_19_000000_create_failed_jobs_table', 2),
(71, '2021_06_13_073237_create_carts_table', 2),
(72, '2021_06_14_075550_create_orders_table', 3),
(73, '2021_06_15_231247_create_messages_table', 3),
(74, '2021_06_13_081016_create_posts_table', 4),
(75, '2021_06_14_075931_create_comments_table', 4);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `posts_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `stanje` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `posts_id`, `quantity`, `price`, `stanje`, `created_at`, `updated_at`) VALUES
(1, 6, 2, 1, 2116, 'odbijeno', '2021-06-22 18:18:30', '2021-06-22 18:18:30'),
(2, 5, 4, 1, 1386, 'prihvaceno', '2021-06-22 18:18:59', '2021-06-22 18:18:59'),
(3, 5, 6, 2, 2698, 'prihvaceno', '2021-06-22 18:19:19', '2021-06-22 18:19:19'),
(4, 4, 2, 1, 2116, 'odbijeno', '2021-06-22 18:21:07', '2021-06-22 18:21:07'),
(5, 5, 29, 3, 2697, 'prihvaceno', '2021-06-22 18:24:50', '2021-06-22 18:24:50'),
(6, 5, 19, 1, 850, 'prihvaceno', '2021-06-22 18:25:32', '2021-06-22 18:25:32'),
(7, 5, 3, 6, 7595, 'odbijeno', '2021-06-22 18:50:05', '2021-06-22 18:50:05'),
(8, 6, 8, 3, 3122, 'na cekanju', '2021-06-22 18:51:11', '2021-06-22 18:51:11'),
(9, 6, 23, 2, 3373, 'na cekanju', '2021-06-22 18:51:40', '2021-06-22 18:51:40'),
(10, 6, 25, 3, 4182, 'odbijeno', '2021-06-22 18:51:56', '2021-06-22 18:51:56'),
(11, 6, 4, 5, 6954, 'na cekanju', '2021-06-22 18:52:06', '2021-06-22 18:52:06'),
(12, 7, 4, 1, 1386, 'prihvaceno', '2021-06-22 18:55:09', '2021-06-22 18:55:09'),
(14, 7, 21, 4, 4882, 'na cekanju', '2021-06-22 18:55:49', '2021-06-22 18:55:49'),
(15, 8, 7, 1, 622, 'na cekanju', '2021-06-22 19:02:28', '2021-06-22 19:02:28'),
(16, 8, 1, 2, 1971, 'prihvaceno', '2021-06-22 19:02:59', '2021-06-22 19:02:59'),
(17, 8, 5, 3, 3507, 'na cekanju', '2021-06-22 19:03:33', '2021-06-22 19:03:33'),
(18, 9, 1, 1, 1349, 'na cekanju', '2021-06-22 19:04:13', '2021-06-22 19:04:13'),
(19, 9, 3, 2, 2698, 'odbijeno', '2021-06-22 19:04:35', '2021-06-22 19:04:35'),
(20, 9, 15, 2, 1943, 'odbijeno', '2021-06-22 19:04:55', '2021-06-22 19:04:55'),
(21, 9, 8, 3, 2446, 'na cekanju', '2021-06-22 19:05:03', '2021-06-22 19:05:03'),
(22, 10, 8, 1, 503, 'na cekanju', '2021-06-22 19:05:54', '2021-06-22 19:05:54'),
(23, 10, 28, 1, 719, 'prihvaceno', '2021-06-22 19:06:18', '2021-06-22 19:06:18');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `slika` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cena` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `created_at`, `updated_at`, `title`, `content`, `slika`, `category`, `cena`, `user_id`) VALUES
(1, '2021-06-22 17:09:30', '2021-06-22 17:09:30', 'Deca vremena', 'Dobitnik jubilarne nagrade Artur Klark za najbolji roman.\r\n\r\nKo će naseliti novu Zemlju?\r\n\r\nEpopeja o borbi čovečanstva da preživi na teraformiranoj planeti.\r\n\r\nKo će naslediti tu novu Zemlju?\r\n\r\nPoslednji ostaci ljudske rase napustili su Zemlju na umoru, u očajničkoj potrazi za novim domom među zvezdama. Prateći stope svojih predaka, oni otkrivaju najveće blago prethodnog doba – svet teraformiran i pripremljen za ljudski život.\r\n\r\nAli u tom novom raju nije baš sve potaman. U dugim godinama otkad je planeta bila napuštena, rad njenih graditelja urodio je katastrofalnim plodovima. Planeta ih ne čeka netaknuta i nenaseljena. Njeni novi gospodari pretvorili su je iz utočišta u najgori košmar čovečanstva.', 'pr15.jpg', 'Naucna fantastika', 1349, 1),
(2, '2021-06-22 17:11:36', '2021-06-22 17:14:17', 'Grčki mitovi', 'Ukoliko te interesuje čudesni svet grčke mitologije, koji nastanjuju bogovi, heroji i raznovrsna izuzetna stvorenja, edukativna knjiga Grčki mitovi zadovoljiće tvoju radoznalost. Predivnim ilustracijama koje vizuelno upotpunjuju tekst i humorom koji je poseban kvalitet svake priče, junaci iz grčke mitologije su približeni mladim čitaocima, a dobro poznate priče obučene su u novo ruho. Knjigu u ruke i zabavi se dok učiš zanimljive informacije o drevnim vremenima.', 'grcki.jpg', 'Decije knjige', 2116, 2),
(3, '2021-06-22 17:16:16', '2021-06-22 17:16:16', 'Pesma sirene', 'Knjiga koja će pomeriti vaše shvatanje muzike! Ako ste muzički fanatik, imate izgrađen muzički ukus i definisan stav po pitanju muzike, poznajete žanrove, izvođače i znate mnoštvo trivija o njihovim životima i karijerama, volite i umete da slušate muziku – onda je ovo knjiga za vas! Vrhunska poslastica za muzičke znalce i sladokusce iz pera Simora Stajna, teškaša muzičke industrije, lovca na talente koji je pomogao usponu velikog broja zvezda od Smitsa i Hedsa, preko Madone do Sila i Ajs Tija!\r\n\r\n„Simor ima zlatno uvo. Taj čovek je u svoj rad uneo enciklopedijsko znanje o muzici i boemsku radost življenja uspevajući da pronađe nove talente tamo gde ih niko drugi ne bi tražio.“ Kej Di Leng\r\n\r\n„Iako svetski poznat diskograf, Simor Stajn je živeo luđe od većine muzičara sa kojima je sarađivao. Hvala bogu što je poživeo da nam ispriča svoju bogatu životnu priču!“ Kris Franc i Tina Vejmut\r\n\r\n„Simor Stajn mi je, vezano za rep muziku, jednom rekao: ’Ne kapiram do kraja to što radiš, ali shvatam koliko je važno.’ Tada sam shvatio da pametni ljudi razumeju neke stvari čak i kada nisu do kraja upoznati sa njima. To ’nešto’ što je on osetio poguralo je moju karijeru.“ Ajs Ti\r\n\r\n„Cilj mi je bio da Smitsi potpišu za Sire Records. Želeli smo da se svrstamo među naše idole, ali smo i više od toga želeli da sarađujemo sa Simorom Stajnom. Slušao sam o svemu što je on uradio za muziku i želeo sam da i mi budemo deo tog nasleđa.“ Džoni Mar, Smits', 'pr31.jpg', 'Umetnost', 1349, 1),
(4, '2021-06-22 17:19:17', '2021-06-22 17:19:17', 'Novi zvučni prostori', 'Knjiga RTS Izdavaštva i Centra za muzičku akciju „Novi zvučni prostori“ priređivača Zorice Premate predstavlja zbornik razgovora održanih na javnim tribinama u organizaciji Centra za muzičku akciju u periodu od 2014. do 2019.godine. Skupovi o umetničkoj muzici stvoreni u nameri da se o savremenoj muzici govori i piše sabrani su prvo u vidu tonskih zapisa koje su imali priliku da čuju slušaoci Radio Beograda 3, a potom i u formi knjige, Zbornika pred čitaocima.\r\nU njemu je predstavljeno više od 30 novih dela 25 domaćih autora. Među njima su kompozitori svih generacija, različitih stilskih orjentacija, više od 70 govornika, muzikologa, muzičkih pisaca, kulturologa, producenata, dizajnera zvuka, izvođača, muzičkih umetnika …\r\nZbornik radova predstavlja presek onog što je do sada učinjeno u okviru istoimenih tribina i nudi se kao materijal za nova istraživanja, sagledavanja, analize i provere mišljenja.', 'pr30.jpg', 'Umetnost', 1386, 2),
(5, '2021-06-22 17:20:50', '2021-06-22 17:20:50', 'Ljubavno pismo', 'Čuvanje tajni je opasna igra…\r\n\r\nLondon, 1995.\r\n\r\nSer Džejms Harison, jedan od najvećih glumaca svoje generacije, preminuo je u devedeset petoj godini života i ostavio ne samo ožalošćenu porodicu već i šokantnu, razornu tajnu koja može da uzdrma englesko društvo do srži.\r\n\r\nDžoani Haslam, ambicioznoj mladoj novinarki, dodeljen je zadatak da napiše članak o ser Džejmsovoj sahrani. Ispraćaju prisustvuju mnoge svetski poznate ličnosti. Ali pod plaštom glamura, Džoana otkriva mračnu priču o pismu ser Džejmsa Harisona čiji je sadržaj očajnički skrivan duže od sedamdeset godina. Kad je pronikla kroz koprenu laži, shvatila je da postoji i druga strana koja pokušava da je spreči da otkrije istinu. I da ne preza ni od čega da dođe do pisma pre nje.\r\n\r\n„Obilje zapleta, osvrta na prošle događaje i dašak romanse održavaju visoku napetost radnje. Svim ljubiteljima dvorskih intriga ili skandala visokog društva, najnoviji roman Lusinde Rajli pruža i jedno i drugo.“ Booklist\r\n\r\n„Iznenađenje za iznenađenjem… Obožavaoci Lusinde Rajli Ljubavno pismo svakako neće ispuštati iz ruku.“ Publishers Weekly', 'pr6.jpg', 'Romani', 1079, 3),
(6, '2021-06-22 17:22:05', '2021-06-22 17:22:05', 'Tijamatin gnev', 'Osmi roman u serijalu Prostranstvo\r\n\r\nHiljadu trista kapija otvorilo se prema sunčevim sistemima širom galaksije. Ljudsko carstvo među tuđinskim ruševinama klizi u propast.\r\n\r\nU mrtvim sistemima gde kapije vode do stvari čudnijih od tuđinskih planeta Elvi Okoje započinje očajničku potragu za prirodom genocida koji se zbio pre nego što su postojala prva ljudska bića, i za oružjem kojim bi se vodio rat protiv sila na rubu zamislivog. Ali cena tog znanja mogla bi da bude viša od cene koju ona može da plati.\r\n\r\nU srcu carstva, Tereza Duarte se priprema da preuzme na sebe teret očeve božanske ambicije. Naučnik sociopata Paolo Kortazar i zatvorenik Džejms Holden u ulozi Mefista samo su dve opasnosti u palati punoj intriga, ali Tereza ima jaku volju i tajne o kojima čak ni njen otac, car, ništa ne zna.\r\n\r\nA širom ljudskog carstva, raštrkana posada Rosinantea vodi hrabru pozadinsku borbu protiv Duarteovog autoritarnog režima. Sećanja na stari poredak blede, a perspektiva budućnosti pod večitom vlašću Lakonije u kojoj čovečanstvo može samo da izgubi izgleda sve izvesnija. Jer protiv strave i užasa koji se kriju među svetovima, hrabrost i ambicija neće biti dovoljne…\r\n\r\n„Kori spretno plete višestruka gledišta kako bi stvorio gustu i živopisnu tapiseriju političkih intriga, ličnih odnosa i sofisticirane tehnologije. Roman pršti od akcije, ali takođe donosi introspektivni pogled na likove dok oni stare i razmišljaju o svojoj svrsi i vrednosti sopstvenog života.“ Booklist\r\n\r\n„Poigravajući se epskim posledicama po čovečanstvo, i pokazujući da nijedan od stalnih likova nije bezbedan pred onim što će se dogoditi, dvojac po imenu Kori ujedno sklapa priču koja se čini i te kako relevantnom za ovo doba: upozorenje na opasnosti koje donose fašizam i totalitarizam.“ Polygon', 'pr8.jpg', 'Romani', 1349, 3),
(7, '2021-06-22 17:23:02', '2021-06-22 17:23:02', 'Zidanje ambisa', 'Neki ambisi postoje, a neke sami stvorimo.\r\n\r\nU manastirskoj tami Visokih Dečana, skriven visoko na kapitelu jednog stuba, vekovima stoji tajanstveni potpis Srđ grešni. Odoleva vremenu, krijući u sebi greh nepoznatog neimara. Ovo je priča o tom grehu.\r\n\r\nVeliki kralj Stefan Uroš III Nemanjić, kome je božjim čudom vraćen vid, počinje 1327. godine da gradi zadužbinu – manastir Dečani.\r\n\r\nDok se smenjuju glasovi trojice junaka – glavnog neimara franjevca Vite Kotoranina, mladog klesara Srđa iz Hilandara i paganina bunardžije Vidoja – senka nečeg strašnog nadviće se nad kamenim zidovima tek započete Crkve Svetog Spasa, senka bolesti protiv koje nema dobrog oružja.\r\n\r\nTrojica junaka kreću na strašnog neprijatelja – da pobede ili da nestanu. U tome će im pomoći čudni, slepi prosjak i jedna pesma. A pre svega zavet njihovog prijateljstva.\r\n\r\nIzvanredno satkana priča sa poetskim nabojem, Zidanje ambisa je roman o burnim vremenima, malim ljudima, jakim ženama, vladarima, oceubicama i slepim svecima… i o velikoj ljubavi.', 'pr7.jpg', 'Romani', 622, 2),
(8, '2021-06-22 17:24:12', '2021-06-22 17:24:12', 'Usamljeni mesec', 'U zvezdanom sistemu kojim upravlja brutalno Vatečko carstvo, osamnaestogodišnja Amani je sanjalica. Mašta o tome kakav bi život bio pre okupacije i iščekuje znak od Dihje da će jednog dana doživeti avanturu i putovati daleko van njenog izolovanog meseca.\r\n\r\nAli kada je kidnapuju je i krišom odvedu u kraljevsku palatu, ona otkriva da je neverovatno slična okrutnoj princezi Maram. Omražena kod porobljenog naroda, Maram traži neophodnu identičnu zamenu, nekog ko je spreman da se pojavljuje u njeno ime i da umre umesto nje.\r\n\r\nIako joj je ta nova uloga nametnuta, Amani ne može a da ne uživa u lepoti palate i vremenu provedenom sa princezinim verenikom Idrisom. Međutim, blistavi sjaj dvorca krije svet nasilja i straha. Ako želi da ponovo vidi svoju porodicu, mora da imitira princezu do savršenstva – samo jedan pogrešan potez može da bude smrtonosan.', 'pr19.jpg', 'Romani', 503, 1),
(9, '2021-06-22 17:25:29', '2021-06-22 17:25:29', 'Priče iz zemljomorja', 'Prva novela, „Nalazač“, svojevrstan je „uvod“, priča iza priče o prve četiri knjige Zemljomorja. Proces njenog pisanja odista je bio poput leta u nepoznato na niti paučine. Nisam imala jasnu predstavu kuda je to mladi Vidra krenuo kada se uputio u svoj mračni svet u kojem vlast imaju rđavi ljudi. Znala sam samo da će doći na Rouk i da će tamo zateći, ili osnovati, Školu. Idući njegovim stopama nadala sam se da ću saznati, za početak, kako su se to čarobnjaci Rouka, onakvi kakvi su bili kada sam ih upoznala, odrekli svoje seksualnosti i kolikog dela ljudskosti su se morali odreći sa njome.\r\nSve priče su svojevrsne ekspedicije – ispituju nejasnoće, ravnotežu i njeno odsustvo, moralne izbore. „Tamnoruža i Dragulj“ takođe se bavi pitanjem čarobnjačkog celibata, ali postavlja i pitanje: ukoliko biste se mogli baviti magijom ili pevati, ali ne i jednim i drugim, šta biste odabrali i zašto? U „Kostima Zemlje“ saznala sam ko je Ogion, ko mu je bio učitelj i koliko daleko magija može ili ne može sezati. Priča „Na Močvarnoj visoravni“ omogućila mi je da se pozabavim onim što nedostaje kada se magija poima isključivo kao moć. Moć nad kim, i šta sa njome činiti? Spasti svet od neprijatelja? Je li to sve? Je li to dovoljno? Ukoliko je moć odgovornost, za koga ste odgovorni? U ovoj priči (kao i u Maču u kamenu T. H. Vajta i mnogim drugim fantazijama) prisustvo životinja ne dozvoljava isključivo antropocentrične konvencije, nego nagoveštava drugačiji, širi poredak stvari.\r\nPoslednja novela, „Vilin Konjic“, direktan je most između knjige Tehanu i poslednjeg romana. Događaji na njenom kraju slede nakon što se završi Tehanu a prethode Drugom vetru. Sve što sam naučila o odnosu ljudi i zmajeva u priči izlazi na površinu, skupa sa spoznajom šta je to na Rouku pošlo po zlu. Počela sam da čujem poslednje velike teme celokupne priče o Zemljomorju. Sve je počelo da dolazi na svoje mesto.', 'pr4.jpg', 'Romani', 899, 3),
(10, '2021-06-22 17:28:22', '2021-06-22 17:28:22', 'Odaja secanja', '„Odvažna priča o ljubavi i traganju, sećanju i ubistvu, smeštena u buduićnost na korak od nas.“ Daily Mail\r\n\r\nBliži vam se smrt.\r\nMožete zauvek da sačuvate pregršt posebnih uspomena.\r\nKoje biste odabrali?\r\n\r\nPrava smrt je stvar prošlosti. Sad večnost možete provoditi iznova proživljavajući svoje najlepše uspomene – prvi poljubac, zaljubljivanje, rođenje dece – i uživajući u njima.\r\n\r\nIzobel je rajski arhitekta i pomaže ljudima na samrti da stvore zagrobni život od svojih uspomena. Kad se zaljubi u Jareka, svog oženjenog klijenta kome se bliži smrt, zna da ne može da ga spase, ali zato može da mu napravi najlepši raj samo za njega.\r\n\r\nIpak, kad Jarekovu ženu pronađu mrtvu, Izobel otkriva mračnu stranu sveta u kome radi i nikome ne može da poveri šta je pronašla…\r\n\r\nOdaja sećanja je uzbudljiva i originalna priča koja prenosi čitaoca u svet koji je zastrašujuće blizak našem, u kome možemo da izbegnemo sve čega se plašimo, pa čak i samu smrt. Ali možemo li pobeći od istine?', 'pr17.jpg', 'Naucna fantastika', 809, 1),
(11, '2021-06-22 17:30:04', '2021-06-22 17:30:04', 'Prvi ljudi na mesecu', 'Genijalni naučnik Kavor otkriva način na koji je moguće međuplanetarno putovanje. U pratnji mladog Bedforda on sleće na Mesec. Susreću se sa naprednom civiliza­cijom nimalo sličnoj ljudskoj. Kavor stanovnicima Me­seca, Selenitima, priča o fizičkim uslovima života na Zemlji, naučnim i tehničkim dostignućima, a naro­čito o ratovima, ljudskoj pohlepi, socijalnoj nejedna­kosti, nepravdi. Smatrajući da bi dublje upoznavanje sa Zemljanima bilo pogubno za njih, Seleniti odlučuju da onemoguće svaki budući kontakt sa njima.\r\n\r\nU romanu Prvi ljudi na Mesecu možda i ponajviše do­lazi do izražaja Velsov svojevrsni antropološki pe­simizam. Naime, on ne veruje da ljudski rod i pored neslućenog naučnog i tehnološkog razvoja ide ka svojoj dobrobiti. Upravo zbog toga njegovo delo je i posle goto­vo sto godina veoma savremeno.', 'pr18.jpg', 'Naucna fantastika', 792, 1),
(12, '2021-06-22 17:31:37', '2021-06-22 17:31:37', 'Izmedju projekta i sudbine', 'Povod za nastanak ove publikacije nalazi se u sećanju na davne dane izlaženja časopisa Moment, u izdanju Dečjih novina iz Gornjeg Milanovca, između 1984. i 1991. godine, u čijoj su redakciji i među saradnicima bili okupljeni brojni prijatelji i poznanici iz redova istoričara umetnosti i umetničkih kritičara, većinom iz Beograda, ali takođe i sa prostora tadašnje zajedničke zemlje, u težnji praćenja, podsticanja i promovisanja savremenih umetničkih zbivanja, kao i proučavanja nedavne istorijske prošlosti u domaćim i međunarodnim kulturnim kontekstima. Svaki broj Momenta n\r\n\r\nastajao je u nezaboravnoj atmosferi neuporedivog entuzijazma, međusobnog poverenja, potpuno profesionalnog i stručnog ulaganja, u gotovo svakodnevnom druženju, kada su se u odnosima kolegijalnih razmena mišljenja rađale, prihvatale i realizovale plodonosne ideje, inicijative, začinjali se i razvijali međuljudski kontakti… Među mnogobrojnim prilozima u Momentu, spontano, u vremenu nastanka, ali takođe i planirano u uređivačkim zamislima, danas se ukazuju i oni što pripadaju italijanskim autorima, kako onima nastalim ekskluzivno za Moment u tekstovima i intervjuima Đulija Karla Argana, Filiberta Mene i Akile Bonito Olive, pri njihovim boravcima u Beogradu, potom Mauricija Kalvezija, Fabija Sarđentinija, Đankarla Politija, Helene Kontove, Đermana Ćelanta, Artura Švarca, tako i prevodima Umberta Eka, Đila Dorflesa, Frančeske Alinovi, kao i protagonista postmoderne postkritike. Sve to daje razloga za tvrdnju o sistematskoj i ažurnoj recepciji cele jedne široke oblasti savremene italijanske kulture, u to vreme posebno inspirativne, aktuelne i relevantne za razumevanje tadašnje epohalne idejne, duhovne i umetničke klime. Priređivač ove antologije, sačinjene izborom iz niza mnogobrojnih bibliografskih jedinica, srećan je što mu se ukazala prilika da sve njene priloge može da okupi i sada na jednom mestu ponovo objavi, stoga svima koji su na različite načine tome doprineli, iskreno želi da izrazi toplu zahvalnost.', 'pr32.jpg', 'Umetnost', 990, 2),
(13, '2021-06-22 17:32:41', '2021-06-22 17:32:41', 'Subverzivni animirani filmovi', '„Ovo je prvi celovit, sistematičan i detaljan opis i analiza animiranog filmskog stvaralaštva producentske kuće Neoplanta film iz Novog Sada(…) predočena je ubedljiva i dokumentovana slika okolnosti u kojima su se u Neoplanti stvarali dokumentarni i igrani filmovi, kao i niz situacija vezanih za takozvani Crni talas…“\r\n\r\niz recenzije dr Živka Popovića', 'pr29.jpg', 'Umetnost', 810, 1),
(14, '2021-06-22 17:34:45', '2021-06-22 17:34:45', 'Klavirska svirka', 'O stvaralaštvu, izvođaštvu i pedagoškom radu istaknutih muzičara\r\n\r\nKnjiga Klavirska muzika bavi se delatnošću istaknutih kompozitora-pijanista – Mocarta, Šopena, Lista, Debisija, Rahmanjinova i niza drugih koji su zahvaljujući klaviru stvorili niz remek-dela muzičke literature, dostigli vrhove izvođačke umetnosti i postavili osnove današnjem podučavanju muzike.', 'pr33.jpg', 'Umetnost', 990, 1),
(15, '2021-06-22 17:35:51', '2021-06-22 17:35:51', 'Konfabulacije', 'Konfabulacija – dopunjavanje praznina u sećanju izmišlјenim detalјima i fiktivnim epizodama, to jest, pričanje izmišlјenih, fantastičnih priča kao istinitih.\r\n\r\nKnjiga pod ovim naslovom sastavljena je od niza beležaka, autorovih crteža koji naglašavaju narativ, sećanja i razmišljanja o životu, umetnosti, muzici i politici.\r\n\r\nKad čitate Berdžera, život vam se nekako promeni. Njegova proza je mudra i lepa, na dirljiv način podstiče na razmišljanje. Čitanje je poput laganog razgovora s nekim ko deli svoje misli o umetnosti, životu, prijateljstvu, slučajnim i svakodnevnim stvarima. U knjizi kaže da „piše skoro 80 ​​godina“. U svim tim zabeleženim rečima pronaći ćete nešto što obogaćuje i prosvećuje. Nekad je to usputno zapažanje o životu, ponekad naziv umetničkog dela koje nikada niste videli, ili jednostavno zapanjujuća očigledna poenta o umetnosti ili životu koju ste propustili. Berdžer je to video – on vidi stvari koje drugi ne vide.\r\n\r\nOvo je knjiga koja se čita i čuva.', 'pr28.jpg', 'Romani', 594, 1),
(16, '2021-06-22 17:37:15', '2021-06-22 17:37:15', 'Ubik', 'Još jednom, Filip K. Dik donosi vizionarske ideje o svetu ka kojem čovečanstvo hrli, reformišući svojim autentičnim književno-umetničkim kvalitetima žanrovsku književnost. Radnja romana se odvija 1992. godine u “Severno-američkoj konfederaciji”, gde su već učestala putovanja na Mesec, a uticajne organizacije zapošljavaju ljude koji rade na blokiranju parapsiholoških moći telepata, kako bi očuvali privatnost. Jednu od njih vodi junak po imenu Ransiter, uz pomoć svoje preminule žene Ele, koja se nalazi u stanju “poluživota”, što je oblik egzistencije koji omogućava ograničenu svest i sposobnost komunikacije nakon smrti.\r\n\r\nUbik je roman Filipa K. Dika iz 1969. godine, koji će postati jedan od njegovih najpoznatijih i najuspešnijih dela. Magazin Time ga je uvrstio na listu od 100 najvažnijih romana napisanih od 1923, ocenivši ga kao “duboko uznemiravajuću egzistencijalnu horor priču, košmar za koji nikada nećemo biti sigurni da smo se iz njega probudili.” Radnja romana se odvija 1992. godine u “Severno-američkoj konfederaciji”, gde su već učestala putovanja na Mesec, a uticajne organizacije zapošljavaju ljude koji rade na blokiranju parapsiholoških moći telepata, kako bi očuvali privatnost. Jednu od njih vodi junak po imenu Ransiter, uz pomoć svoje preminule žene Ele, koja se nalazi u stanju “poluživota”, što je oblik egzistencije koji omogućava ograničenu svest i sposobnost komunikacije nakon smrti. Još jednom, Filip K. Dik donosi vizionarske ideje o svetu ka kojem čovečanstvo hrli, reformišući svojim autentičnim književno-umetničkim kvalitetima žanrovsku književnost.', 'pr16.jpg', 'Naucna fantastika', 224, 1),
(17, '2021-06-22 17:39:05', '2021-06-22 17:39:05', 'Digitalni svet za 1. razred', 'Dodatno nastavno sredstvo Digitalni svet 1, autora Gordane Rackov i Arpada Pastora ima 124 strane koje prate realizaciju svih nastavnih tema za predmet Digitalni svet za prvi razred osnovne škole u okviru godišnjeg fonda od 36 časova.\r\n\r\nSadržaji dodatnog nastavnog sredstva podeljeni su u tri oblasti: Digitalno društvo, Bezbedno korišćenje digitalnih uređaja i Algoritamski način razmišljanja. Prilagođeni su predznanju i razvojnom nivou učenika, ali su sa druge strane i dovoljno izazovni i nalaze se u zoni narednog razvoja.\r\n\r\nRazličiti zadaci i vežbe pružaju mogućnost učenicima da se upoznaju sa novim predmetom na kreativan i zanimljiv način kako bi istražili Digitalni svet.', 'pr21.jpg', 'Udzbenici', 640, 1),
(18, '2021-06-22 17:40:30', '2021-06-22 17:40:30', 'Geografija', 'Geografija 6, udžbenik za šesti razred osnovne škole koncepcijski se nastavlja na udžbenik za peti razred. Obrađuju se sledeće teme: geografska karta, stanovništvo, naselja, privreda, država, regije i globalni procesi. Udžbenik će svojim savremenim dizajnom i pristupom učiniti da se gradivo savlada jednostavnije, a usvojeno znanje učini trajnim i dugoročnim. Udžbenik je bogat ilustrativnim i kartografskim materijalom.', 'pr26.jpg', 'Udzbenici', 910, 2),
(19, '2021-06-22 17:41:32', '2021-06-22 17:41:32', 'Informatika i racunarstvo za 7. razred', 'Udžbenik je osmišljen da na zanimljiv način, uz brojne međupredmetne korelacije, proširuje i nadograđuje poznavanje digitalnih sadržaja i rada s programima za njihovu obradu i prezentovanje, kao i bezbednog pristupa i rada na internetu. Postupnost i metodičnost u izlaganju sadržaja uklopljenog u atraktivan grafički dizajn doprinosi lakšem savladavanju gradiva. Predstavljene su najbolje ocenjene besplatne programske aplikacije kao što su GIMPi Inkscape. Zadaci u lekcijama osmišljeni su da povezuju znanje i zahtevaju primenu gradiva cele lekcije. Kartonski dodatak uz udžbenik sadrži pregled osnovnih funkcija u Python-u i koordinatne mreže kao pomoću za crtanje u Pygameprozoru. Projektni zadaci na kraju poglavlja osmišljeni su da podstiču sticanje kompetencija digitalne pismenosti, bezbednog komuniciranja u digitalnom okruženju i razvoj međupredmetnih kompetencija.\r\n\r\nDigitalni udžbenik:video-zapisi tutorijala, interaktivni testovi za proveru znanja.', 'pr23.jpg', 'Udzbenici', 850, 1),
(20, '2021-06-22 17:42:25', '2021-06-22 17:42:25', 'Istorija za 7. razred Udžbenik', 'Udžbenik prema novom Planu i programu nastave i učenja, u potpunosti zasnovan na nastavi orijentisanoj na ishode.\r\n\r\n• Visok nivo vertikalne i horizontalne korelacije.\r\n\r\n• Motivaciona pitanja koja imaju podsticajnu funkciju u razvijanju istorijskog mišljenja.\r\n\r\n• Dodatne zanimljivosti za motivisanje učenika na kontinuirano usavršavanje i širenje saznajnih vidika.\r\n\r\n• Pažljivo odabrani istorijski izvori sa metodički vešto vođenim pitanjima za razvijanje kritičkom mišljenja i proveru stepena razumevanja pročitanog teksta.\r\n\r\n• Sistematizacije sa pitanjima različitih nivoa postignuća.\r\n\r\n• Primeri za realizaciju projektne nastave, zadaci različite strukture i koncepta za individualni ili grupni rad, kojim se razvija smisleno, problemsko, divergentno, kritičko i kooperativno učenje.\r\n\r\n• Mnoštvo prikaza teritorija.\r\n\r\n• Likovno-grafički izraz koji odgovara horizontu interesovanja današnjih generacija.\r\n\r\n• Mnoštvo fotografija kojima se potkrepljuje sadržaj, što doprinosi visokom nivou opšte kulture i informisanosti, kao i negovanju ljubavi prema nacionalnoj i svetskoj istoriji, kulturi i umetnosti.\r\n\r\n• Naučno zasnovane činjenice, pojmovi, objašnjenja i zanimljivosti pomažu učeniku da stekne saznanja o istorijskim procesima i pojavama u prošlosti i njihovim posledicama te da razvije kritičko mišljenje i izgradi svoje stavove i vrednosti, kao i odgovoran odnos prema nacionalnom identitetu, kulturno-istorijskom nasleđu, društvu i državi u kojoj živi.', 'pr5.jpg', 'Udzbenici', 890, 1),
(21, '2021-06-22 17:44:36', '2021-06-22 17:44:36', 'Likovna Kultura', 'Likovna kultura 6, udžbenik za šesti razred osnovne škole ima razvojno-formativnu ulogu sa fokusom na učenju kao konstrukciji znanja. Pažljivo osmišljenim aktivnostima doprinosi stvaranju pedagoške interakcije između učenika i udžbenika i učenika i nastavnika.', 'pr25.jpg', 'Udzbenici', 690, 3),
(22, '2021-06-22 17:45:25', '2021-06-22 17:45:25', 'Srpski jezik – Citanka', 'Razvijena i razgranata tumačenja književnog dela koja obuhvataju sve njegove aspekte, nastala sa ciljem da nastavniku budu kompletna priprema za čas, a da učeniku koji je izostao sa časa pomognu da postupno i sistematično usvoji propušteno gradivo;\r\n\r\nknjiževno-teorijski pojmovi objašnjeni rečnikom koji razume učenik sedmog razreda, bez komplikovanih i oveštalih fraza koje su uobičajene, a učeniku nisu od pomoći da na pravi način razume i usvoji znanje o novom književnom pojmu. Pojmovi su dovedeni u vezu sa književnim delom koje se obrađuje ili je pri njihovom tumačenju aktivirano prethodno znanje i iskustvo učenika;\r\n\r\nobrađuje se najviše do 4 književno-teorijska pojma u jednoj lekciji;\r\n\r\nsva pitanja u udžbeniku, kao i sve sistematizacije date su u istoj formi pitanja koja učenike očekuju na maloj maturi, što je postepena priprema za završni test u obrazovanju. Izdavačka kuća Vulkan se po tome posebno razlikuje od ostalih izdavača jer su svi njeni udžbenici, dodatna nastavna sredstva za srpski jezik, kao i lektira osmišljeni da pitanjima simuliraju test na završnom ispitu, te da se učenici od petog razreda konstatno pripremaju za završni ispit u osnovnom obrazovanju;\r\n\r\nZvuci prošlosti – nov, jedinstveni segment aparature, zamišljen kao enciklopedijske odrednice koje su tematski ili motivski povezane sa delom koje se obrađuje. Od učenika se očekuje da dobro prouče tekst, motivišu se na dodatno istraživanje literature i drugih izvora znanja da bi otkrili odgovor. Pitanja u ovoj rubrici data su u formi pitanja koja dolaze na maloj maturi;\r\n\r\nraznovrsni domaći zadaci koji podstiču učenike da na drugačiji i kreativan način istražuju, dopune i obogate svoje znanje. Zadatke učenik bira prema ličnom afinitetu, sklonostima, interesovanjima ili talentu. Visok nivo međupredmetne korelacije – likovno, geografija, istorija, muzičko, informatika, veronauka, građansko vaspitanje…\r\n\r\nvizuelno-grafičkim rešenjem udžbenik odgovara horizontu interesovanja današnjih generacija;\r\n\r\nvisok nivo opšte kulture i informisanosti ostvaren kroz analizu sadržaja i propratni likovni materijal (reprodukcije slika, spomenika kulture, dela od opšteg nacionalnog značaja, fototipska izdanja, spomen-kompleksi…), koji doprinosi negovanju ljubavi prema nacionalnoj i svetskoj kulturi i umetnosti;\r\n\r\nudžbenik je zadacima i nalozima usklađen sa opštom težnjom o razvijanju digitalnog obrazovanja i pismenosti i u tome se značajno razlikuje od drugi udžbenika: snimanje pametnim telefonom, izrada PPT prezentacija, animacija, video-zapisa, korišćenje raznih programa koji su obrađeni na časovima informatike – Movie Maker, Scratch i dr.', 'pr24.jpg', 'Udzbenici', 930, 1),
(23, '2021-06-22 17:47:49', '2021-06-22 17:47:49', 'Francuska avantura', '„Francuska avantura“ je putopisna bajka u kojoj se prepliću nauka i čarolija, istorija i sadašnjica. To je čitalačka igra obogaćena zanimljivim ilustracijama – u kojoj jednako učestvuju i odrasli i deca. Odrasli podučavajući i vodeći glasom, a deca oživljavajući maštom svetove nauke i knjige.\r\n\r\nNa ulicama starog grada čuveni naučnik Blez Paskal upoznaje dečaka Luku i moli ga za pomoć. Objašnjava mu da se mašina za računanje, koju je napravio pre nekoliko vekova, našla u opasnosti jer su zli naučnik i zla vila isplanirali da je pretvore u vremeplov i osvoje svet.\r\n\r\nPre nego Luka krene u „spasavanje današnjice i mašine“ ima zadatak da pronađe smotanu čuvar-vilu Anđelinu koja će ga greškom odvesti u vreme Gala i Rimljana, umesto u doba kada je Paskal napravio mašinu.\r\n\r\nKrenimo u avanturu koja spaja prijateljstvo, istoriju, nauku i poseban čarobni svet čuvar-vila.', 'pr10.jpg', 'Decije knjige', 1257, 1),
(24, '2021-06-22 17:48:46', '2021-06-22 17:48:46', 'Žirafe ne znaju da plešu', 'Žile beše visoka žirafa\r\nvrata dugačkog i vitkog, jasno,\r\nali kolena mu behu kriva,\r\na noge tanke, tanke užasno.\r\n\r\nŽile nije bio dobar plesač, mada je svake godine dolazio na takmičenje „Džungla pleše“. Ali jedne divne večeri okupane mesečinom, Žile je otkrio da onima koji su drugačiji, treba i drugačija muzika da svira…\r\n\r\nZabavna, poučna i dirljiva priča u stihovima Džajlsa Andrea koju je prelepo ilustrovao Gaj Parker-Ris.', 'pr11.jpg', 'Decije knjige', 444, 1),
(25, '2021-06-22 17:50:03', '2021-06-22 17:50:03', 'Narodne priče i umotvorine', 'Vratimo se lepoti srpskog jezika i narodne mašte\r\n\r\nOd davnina ljudi veruju u snagu reči, u mudrost koja je utisnuta u njih i u melodiju koju nose. Nekada su ovi kratki oblici bili i čuvari znanja, i otkrivalice sveta oko nas, i vežbe za oštrenje uma, i zabavno ispunjavanje dokolice.\r\n\r\nNamenjena onima koji čitaju deci, ali i deci koja razumeju pročitano, ovo je razigrana knjiga satkana od najfinijih niti iz naše tradicije.\r\n\r\nPriče • Poslovice • Razbrajalice • Brzalice • Zagonetke • Pitalice • Narodna verovanja • Kazivanja u stihu', 'pr13.jpg', 'Decije knjige', 809, 2),
(26, '2021-06-22 17:51:36', '2021-06-22 17:51:36', 'Kaštanka', 'Anton Pavlovič Čehov (1860–1904) bio je ruski prozaista i dramski pisac. Po profesiji je bio lekar i pisao tokom čitavog života. Izvršio je veliki uticaj na razvoj modernog teatra, i smatra se jednim od najvećih majstora kratke priče. Njegove najznačajnije drame su Galeb, Ujka Vanja, Tri sestre i Višnjik, a neke od najpoznatijih priča su Dama sa psetancetom, Šala i Tuga.\r\nKaštanka, priča o keruši koja se izgubila i njenim neobičnim doživljajima, izdvojila nam se svojim šarmom među njegovim pričama za decu, i odlučili smo da vam je priredimo.\r\n***\r\nBiblioteka carević Ivan zamišljena je kao izbor knjiga za decu. Poželeli smo da podelimo sa vama knjige koje su nama bile zanimljive dok smo odrastali i zauvek ostale važne, kao i one na koje smo naišli sada kada smo navodno odrasli. Čini nam se da su to priče kroz koje se svet može zamisliti i doživeti u svojim raznim lepotama i istinama.', 'pr12.jpg', 'Decije knjige', 792, 1),
(27, '2021-06-22 17:53:08', '2021-06-22 17:53:08', 'Decak i vila', '„Dečak i vila“ je knjiga napisana kao zagrljaj, kao najlepša želja, kao čuvar-vila koja će vam osvetliti put kroz život, kao zvezda nekog voljenog ko vas prati i čuva. Kada vam nedostaje savet, kada vam nedostaje neko važan,otvorite „Dečaka i vilu“. Među koricama ove knjige krije se zaštitnička, majčinska ljubav za svu decu sveta.\r\n\r\nDečak je usamljen, nedostaju mu prijatelji, baka i deka i prezauzeti roditelji. Jedne noći, pojaviće se vila koja će mu ponuditi Vilinski ugovor o odrastanju, dečak će ga nesvesno potpisati i ući u svet odbačenih, zavidnih, ali i svet velikih boraca – onih koji nikada ne odustaju.\r\n\r\nKrenimo u avanturu sa ukusom vilinskog meda, suočimo se sa ljudskim manama i vrlinama, upoznajmo najposebnije junake Beskrilu i Vilana…', 'pr20.jpg', 'Decije knjige', 717, 1),
(28, '2021-06-22 17:55:22', '2021-06-22 17:55:22', 'Nerazdvojne', 'Neobjavljeni kratki roman Simon de Bovoar Nerazdvojne dočarava njenu veliku ljubav iz detinjstva prema prijateljici, Zazi, čija će je tragična smrt, neposredno izazvana predrasudama i normama tadašnjeg društva, proganjati čitavog života. Nerazdvojne je i roman koji uprizoruje seksualno i intelektualno obrazovanje dveju mladih devojaka, buntovnih u svetu koji ometa i ograničava njihovu slobodnu misao.\r\nOvaj autobiografski tekst, napisan pet godina nakon objavljivanja Drugog pola, lucidno i emotivno dočarava prva iskustva revolta i usvajanja feminističke filozofije, događaje detinjstva kao mesta emancipacije, iskustva prijateljstva kao početke smelosti i nezavisnosti.\r\nNerazdvojne opisuju ličnu bitku Simon de Bovoar protiv konvencionalnih očekivanja i potcrtavaju njenu intelektualnu i egzistencijalnu ambiciju. Roman, previše intiman da bi bio objavljen, nedavno je u njenoj arhivi pronašla njena usvojena ćerka, Silvi Le Bon de Bovoar, koja je napisala predgovor.', 'pr9.jpg', 'Romani', 719, 1),
(29, '2021-06-22 17:56:43', '2021-06-22 17:56:43', 'Povratak', 'Trevor Benson nikad nije nameravao da se vrati u Nju Bern u Severnoj Karolini. Radio je u Avganistanu kao ortopedski hirurg sve dok jednog dana ispred bolnice nije eksplodirala minobacačka granata. Zadobivši teške povrede, vratio se u domovinu, a trošna, drvena kućica koju je nasledio od dede izgleda mu kao dobro mesto za oporavak, baš kao i bilo koje drugo.\r\n\r\nU Nju Bernu brine o dedinim voljenim košnicama i priprema se za drugu specijalizaciju na fakultetu. Kada sretne Natali Masterson, zamenika šerifa, neplanirano će se kod njega probuditi osećanja koja ne može da ignoriše. Iako je očigledno da je i on njoj drag, Natali je povremeno neočekivano veoma suzdržana prema njemu. Trevor počinje da se pita šta je uzrok takvom njenom ponašanju.\r\n\r\nU život mu ulazi još jedna tajnovita osoba, tinejdžerka Kali koja živi u obližnjem kampu za prikolice. Tvrdeći da joj je sedamnaest godina, ona radi u prodavnici mešovite robe i izbegava društvo. Otkrivši da se svojevremeno sprijateljila s njegovim dedom, Trevor se nada da Kali može da rasvetli misteriozne okolnosti pod kojima je njegov deda umro, ali ona nudi skromne nagoveštaje sve dok se ne ispostavi da je Kalina prošlost isprepletena sa starčevom smrću više nego što je Trevor mogao da pretpostavi.\r\n\r\nU nastojanju da otkrije Nataline i Kaline tajne, Trevor će naučiti šta zaista znače ljubav i opraštanje… i da se u životu, da bismo krenuli dalje, često moram vratiti na mesto gde je sve počelo.\r\n\r\n„Veoma mudar, novi Sparksov roman podseća nas da smo svi ’samo ljudi’, skloni greškama i nesavršeni. Snažne emocije obuzeće vas već od prvih stranica.“ – Popsugar', 'pr34.jpg', 'Romani', 899, 2),
(30, '2021-06-22 18:00:47', '2021-06-22 18:00:47', 'Mračna šuma', 'Dobitnik nagrade Hugo\r\n\r\nDrugi roman trilogije Besede o Zemljinoj prošlosti\r\n\r\nZamislite da je čitav univerzum jedna šuma kojom krstare nebrojeni, bezimeni predatori. U toj šumi preživljavaju oni koji su neprimetni, a civilizacija koja otkrije svoje postojanje postaje lak plen. Zemlja se razotkrila. Predatori dolaze.\r\n\r\nDerviški ples Trisolarisovih zvezda naterao je ovu naprednu rasu u izgnanstvo. Trisolarijanska flota nezadrživo grabi ka Sunčevom sistemu. Njihove verne sluge sofoni pažljivo motre na svaki potez čovečanstva, držeći nauku pod svojom kontrolom. Um postaje poslednje bezbedno uporište, a izbavljenje ljudskog roda pada u ruke zidozornika sa gotovo neograničenim ovlašćenjima. Protiv njih ustaju izdajnici ljudskog roda čiji je zadatak da poruše bedeme spasonosnog umovanja.\r\n\r\nTrisolarijanska svita šalje glasonošu.\r\n\r\nŠahovska majstorica počinje i završava se u mračnoj šumi.\r\n\r\n„Glavni pokretač radnje su autorova sumorna ali veoma uverljiva, razložna i gotovo filozofska promišljanja sa blistavim idejama komplikovane strukture koje ponekad zahtevaju veću čitaočevu pažnju, ali pisac taj naš trud višestruko nagrađuje. Mračna šuma je izuzetan roman. Za svaku preporuku.“ Kirkus Reviews\r\n\r\n„Mračna šuma je važan roman čiji će vas obrti oduševiti i šokirati, a metafore nagnati na dublja promišljanja o inherentnoj prirodi inteligentnog života u univerzumu.“ thebooksmugglers.com', 'pr14.jpg', 'Naucna fantastika', 1150, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `two_factor_secret`, `two_factor_recovery_codes`, `remember_token`, `created_at`, `updated_at`, `type`) VALUES
(1, 'Nemanja Petrovic', 'admin@admin.rs', NULL, '$2y$10$Ksa.W37.Ph8b9HAeJw4ghuqiHuJwKaD3qDSgKdgA36lo83v6RPpwS', NULL, NULL, NULL, '2021-06-22 18:03:49', '2021-06-22 18:03:49', 'admin'),
(2, 'Editor', 'editor@editor.rs', NULL, '$2y$10$O/WQ.csA8PMFXe.Nm4MnJ.b7uHAS2JM0Oqf1Rf2RdGUyzh8ravGgO', NULL, NULL, NULL, '2021-06-22 18:05:15', '2021-06-22 18:05:15', 'editor'),
(3, 'Editor2', 'editor2@editor2.rs', NULL, '$2y$10$gGUIqHDLZMUFKjLparhgPeQoWB/h11cxRL528u88klfguDYhSb1By', NULL, NULL, NULL, '2021-06-22 18:05:53', '2021-06-22 18:05:53', 'editor'),
(4, 'User', 'user@user.rs', NULL, '$2y$10$35B8V0.5NqAWTViOLjoKWOgkUSYUeh9NvPfIhjEdA/xyUawWIH0wy', NULL, NULL, NULL, '2021-06-22 18:06:33', '2021-06-22 18:06:33', 'registered'),
(5, 'Pera Peric', 'pera@pera.rs', NULL, '$2y$10$4bAqilucN.y8IDImFcR/hOkTDKJaMbdmqvYGok2uZughjCcIczPFu', NULL, NULL, NULL, '2021-06-22 18:17:02', '2021-06-22 18:17:02', 'registered'),
(6, 'Mika Mikic', 'mika@mika.rs', NULL, '$2y$10$GYJ96N0/eCyrX1OwEOxH1eObtn6FnhURuU0euX2NJ91nWF2xRDNFi', NULL, NULL, NULL, '2021-06-22 18:17:22', '2021-06-22 18:17:22', 'registered'),
(7, 'Milos', 'milos@milos.rs', NULL, '$2y$10$sJRFBGMX6sEMl8U61/G3PuJmqA/xmLJ.tt5tXr5FLO6qPBR71Ge7O', NULL, NULL, NULL, '2021-06-22 18:54:40', '2021-06-22 18:54:40', 'registered'),
(8, 'Sara Saric', 'sara@sara.rs', NULL, '$2y$10$URM.Vd9NEuoVHfUs3MA7q.utJovDA93cVkEHWoiW/LFnvTOYzGcTO', NULL, NULL, NULL, '2021-06-22 19:02:21', '2021-06-22 19:02:21', 'registered'),
(11, 'Milica Milic', 'milica@milica.rs', NULL, '$2y$10$PD5AhjyowN5J212Y24xwwemyoEZ3kagw28r.qS13rzK9dNPBZkrky', NULL, NULL, NULL, '2021-06-22 19:41:22', '2021-06-22 19:41:22', 'registered');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
