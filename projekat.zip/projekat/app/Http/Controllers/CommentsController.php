<?php

namespace App\Http\Controllers;
use App\Models\Post;
use App\Models\Comment;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Session;

class CommentsController extends Controller
{
    public function comment(Request $request){
        // echo "<pre>"; print_r($data); die;
        $comments = $request->comments;
        $post_id = $request->post_id;

        $insert = new Comment;
        $insert->user_id=$request->user()->id;
        $insert->post_id = $post_id;
        $insert->comments = $comments;
    
        $insert->save();
        Session::flash('success_msg', 'Post added successfully!');
        return redirect()->back();
    }
    public function update($id, Request $request){
        $comment = Comment::find($id);
     
        $comment->comments = $request->comment;
        $comment->update();
		// Comment::find($id)->update($comment);
       
        Session::flash('error_msg', 'Sva polja su obavezna!');
        Session::flash('success_msg', 'Post updated successfully!');

        return redirect()->back();
    }
    public function viewComment($id,Request $request){
        //SELECT comments.id,comments.comments,comments.created_at,posts.title,users.name,users.email FROM comments
        //INNER JOIN posts ON comments.post_id = posts.id INNER JOIN users ON comments.user_id = users.id

		$post = Post::find($id);

        $user_id=$request->user()->id;
        $name = DB::table('users')->where('users.id',$user_id)->get();

        $comments = DB::table('posts')
        ->select('comments.id','comments.comments','comments.created_at','posts.title','users.name','users.email')
        ->join('comments','posts.id','=','comments.post_id')
        ->join('users', 'users.id', '=', 'comments.user_id')
        ->where('posts.id',$id)->orderBy('comments.id','desc')
        ->get();

        return view('posts-comment',['post'=>$post],['comments' => $comments ,'name' => $name]);
        }
    public function delete($id,Request $request){
        // Post::find($id)->delete();
        $com =  Comment::find($id);
            
        if($request->user()->cannot('delete',$com)){
            abort(403);
        }
        $post = DB::table('comments')->where('id',$id)->delete();
        
        //store status message
        Session::flash('success_msg', 'Comment deleted successfully!');

        return redirect()->back();
    }
}