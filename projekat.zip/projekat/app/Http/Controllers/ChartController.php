<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ChartController extends Controller
{
    public function chart(Request $request){
        $user_id=$request->user()->id;
        $name = DB::table('users')->where('users.id',$user_id)->get();

        return view('admin-panel',['name'=>$name]);
    }
}
