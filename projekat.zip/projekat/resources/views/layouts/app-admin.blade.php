
<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
     <title>Admin-panel</title>
</head>

<body style=" font-family: Arial, Helvetica, sans-serif;
background-color: #f1f1f1;
position: relative;
padding-bottom: 58px;
min-height: 100vh;
">
    <div id="app">
        <nav class="navbar navbar-expand-lg navbar-light shadow">
            <div class="container-fluid">
            @yield('title')
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="{{ route('admin-panel') }}">Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="{{ route('admin-posts') }}">Postovi</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="{{ route('admin-orders') }}">Narudbine</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="{{ route('admin-users') }}">Users</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="{{ route('admin-messages') }}">Messages</a>
                        </li>
                    </ul>
                </div>
                <div class="d-flex">
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                
                    <a class="d-flex align-items-center nav-link dropdown-toggle dropdown-toggle-nocaret" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <div class="user-info ps-3">
							@foreach($name as $n)
                                <p class="text-dark h4">{{ $n->name }}</p>
                                <p class="text-dark h6 ms-6">{{ $n->type }}</p>
							@endforeach
                            </div>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="{{ route('admin-panel') }}">Dashboard</a>
                            </li>
                            <li><a class="dropdown-item" href="{{ route('admin-posts') }}">Postovi</a>
                            </li>
                            <li><a class="dropdown-item" href="{{ route('admin-orders') }}">Narudzbine</a>
                            </li>
                            <li>
                                <div class="dropdown-divider mb-0"></div>
                            </li>
                            <li><a class="dropdown-item" href="{{ route('logout') }}"
                                onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                                {{ __('Logout') }}
                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                        @csrf
                                    </form>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>            
    <div class="page-wrapper mt-4" style="margin-left:100px;margin-right:100px;">
        <div class="page-content">
            <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
                @yield('naslov')
            </div>

    <main style="margin-bottom:50px;">
        @yield('content')
    </main>
    <footer style="text-align: center;
      background-color: #333;
      color: #fff;
      margin-left:-100px;
      padding: 20px;
      position: absolute;
      bottom: 0;
      width: 100%;">
        <p>Copyright &copy; <script>document.write(new Date().getFullYear());</script>, Nemanja Petrović</p>
      </footer>

    </body>
</html>