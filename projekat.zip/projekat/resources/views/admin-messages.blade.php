@extends('layouts.app-admin')

@section('title')
    <a class="navbar-brand text-success h1" href="">
    {{  'Admin-panel-Messages' }}
    </a>
@endsection
@section('naslov')
    <h2>{{  'Messages' }}</h2>
@endsection
@section('content')
	<div class="card">
		<div class="card-body">
			<div class="d-lg-flex align-items-center mb-4 gap-3">
				<div class="position-relative">
					<form action="{{ route('admin-messages') }}" method="get" role="search">
                        <!-- {{ csrf_field() }} -->
                        <div class="input-group">
                            <input type="text" class="form-control ps-5 radius-30 mx-3" name="q" placeholder="Search Users">
                            <span class="input-group-btn">
                            <button type="submit" class="btn btn-primary">Search
                            </button>
                            </span>
                        </div>
                    </form>
				</div>
			</div>
			<div class="table-responsive">
				<table class="table mb-0 table table-striped card-table table-condensed table-nowrap border">
					<thead class="table-light">
						<tr>
							<th>Name</th>
							<th>Email</th>
							<th>Subject</th>
							<th>Messages</th>
							<th>Date created</th>
							<th>Actions</th>
						</tr>
					</thead>
					<tbody>	
					@foreach($messages as $message)
						<tr>
							<td>{{$message->name }}</td>
							<td>{{$message->email}}</td>
							<td>{{$message->subject}}</td>
							<td>{{$message->messages}}</td>
							<td>{{date('d.m.Y H:i', strtotime($message->created_at))}}</i><br/></td>
							<td><a href="{{ route('admin-messages.delete', $message->id) }}" class="btn btn-danger" onclick="return confirm('Are you sure to delete?')">Delete</a>	
						</tr>
							@endforeach
					</tbody>
				</table>
			</div>
		</div>
	</div>
@endsection
