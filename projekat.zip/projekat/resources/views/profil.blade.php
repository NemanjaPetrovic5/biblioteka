@extends('layouts.app')

@section('content')

<main class="mt-5 pt-4">
    <div class="container rounded bg-white mt-5 mb-5">
        <div class="row">
            <div class="col-md-3 border-right">
            @foreach($name as $n)
                <div class="d-flex flex-column align-items-center text-center p-3 py-5">
                    <img src="{{asset('storage/images/profil.jpg')}}  " width="80%" height="250px" alt="" class="rounded-circle " width="150px">
                <span class="font-weight-bold">{{ $n->name }}</span><span class="text-black-50">{{ $n->email }}</span><span> </span></div>
            @endforeach
            </div>
        <div class="col-md-9 border-right">
            <div class="p-3 py-5">
                <div class="card ">
                    <div class="card-header">
                    @foreach($name as $n)
                    <h5 class="card-title">{{ $n->name }} - Procitane knjige</h5>
                    @endforeach
                    <div class="row">
                        <table class="table table-striped card-table table-condensed mt-0 table-nowrap border">
                            <thead>
                                <tr>
                                    <th>Slika</th>
                                    <th>Naziv</th>
                                    <th>Kolicina</th>
                                    <th>Datum narudzbe</th>
                                    <th>Cena</th>           
                                </tr>
                            </thead>
                            <tbody>
                            <?php $total = 0; ?>
                            <?php $quantity = 0; ?>

                            @foreach($post as $post)
                                <tr>
                                    <td> <img src="{{asset('storage/uploads/' . $post->slika)}}  " width="50px" height="50px" alt=""> </td>
                                    <td>{{$post->title}}</td>
                                    <td>{{$post->quantity}}</td>
                                    <td>{{$post->created_at}}</td>
                                    <td>{{$post->price}}.00 din</td>
                                </tr>
                                <?php $total = $total + ($post->cena * $post->quantity) ?>
                                <?php $quantity = $quantity + $post->quantity ?>
                            @endforeach 
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="p-3">
            <div class="card ">
                <div class="card-header">
                @foreach($name as $n)
                <h5 class="card-title">{{ $n->name }} - Komentari</h5>
                @endforeach
                    <table class="table table-striped card-table table-condensed mt-0 table-nowrap border">
                        <thead>
                            <tr>
                                <th>Naziv</th>
                                <th>Komentar</th>
                                <th>Edit</th> 
                                <th>Datum objave</th>
                                <th>Delete</th>           
                            </tr>
                        </thead>
                        <tbody>
                        @foreach($com as $c)
                            <tr>
                                <td> <img src="{{asset('storage/uploads/' . $c->slika)}}  " width="50px" height="50px" alt=""> </td>
                                <td>{{$c->title}}</td>
                                <td> <form action="{{ route('comments.update', $c->id) }}" enctype="multipart/form-data" method="POST" class="form-horizontal">
                            {{ csrf_field() }}
                                <div class="form-group">
                                    <div class="col-sm-10">
                                        <textarea type="text" name="comment" id="comment" class="form-control" >{{ $c->comments }}</textarea>
                                    </div>
                                <div class="form-group mt-4 text-center">
                                    <div class="col-sm-offset-2 col-sm-10">
                                        <input type="submit" class="btn btn-success" value="Update Comment" />
                                    </div>
                                </div>
                            </form></td>
                                <td>{{ $c->created_at}}</td>
                                <td><a href="{{ route('deleteComment', $c->id) }}" class="btn btn-danger" onclick="return confirm('Are you sure to delete?')">Delete</a></td>
                            </tr>
                        @endforeach     
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div> 
@endsection