@extends('layouts.app-admin')

@section('title')
    <a class="navbar-brand text-success h1" href="">
    {{  'Admin-panel-Orders' }}
    </a>
@endsection
@section('naslov')
    <h2>{{  'Orders' }}</h2>
@endsection
@section('content')
    <div class="card">
        <div class="card-body">
            <div class="d-lg-flex align-items-center mb-4 gap-3">
                
            </div>
            <div class="table-responsive">
            @if(Session::has('error_message'))
                            <div class="alert alert-danger">
                              {{ Session::get('error_message') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        @endif
                        @if(Session::has('success_msg'))
                            <div class="alert alert-success">
                                {{ Session::get('success_msg') }}
                            </div>
                        @endif
                <table class="table mb-0 table table-striped card-table table-condensed table-nowrap border m-6">
                    <thead class="table-light">
                        <tr>
                            <th>Slika</th>
                            <th>Post title</th>
                            <th>Name</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Date created</th>
                            <th>Status</th>
                            <th>Opcion</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                    @foreach($posts as $p)
                        <tr>
                        <td><img src="{{asset('storage/uploads/' . $p->slika)}}  " width="120px" height="100px" alt=""></td>

                            <td>{{ $p->title }}</td>
                            <td>{{ $p->name }}</td>
                            <td>{{ $p->cena }}.00 din</td>
                            <td>{{ $p->quantity }}</td>
                            <td>{{date('d.m.Y H:i', strtotime($p->created_at))}}</i><br/></td>
                            <td>{{ $p->stanje }}</td>
                            <?php $stanje =  $p->stanje  ?>
                            @if(($stanje) === 'na cekanju')
                            <td>    
                                <a href="{{ route('posts.potvrdi', $p->id) }}" class="btn btn-primary btn-sm radius-30 px-4"name="stanje" id="">Potvrdi</a>
                                <a href="{{ route('posts.odbij', $p->id) }}" class="btn btn-warning btn-sm radius-30 px-4"name="stanje" id="">Odbij</a>
                            </td>
                            @else
                            <td></td>
                            @endif
                            <td><a href="{{ route('orders.delete', $p->id) }}" class="btn btn-danger" onclick="return confirm('Are you sure to delete?')">Delete</a></td>	
                        </tr>
                     @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection