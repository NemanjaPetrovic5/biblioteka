@extends('layouts.app-admin')

@section('title')
    <a class="navbar-brand text-success h1" href="">
    {{  'Admin-panel-Add User' }}
    </a>
@endsection

@section('content')
	<div class="card">
        <div class="card-body">
            <div class="d-lg-flex align-items-center">
                <div class="ms-auto"><a href="{{ route('admin-users') }}" class="btn btn-primary radius-30 mt-2 mt-lg-0"><i class="bx bxs-plus-square"></i>Back</a></div>
            </div>
            <div class="table-responsive">
                <div class="card-body">
                    <div class="card">
                        <div class="card-header ">{{ __('Register new user') }}</div>
                            <form method="POST" action="{{ route('dodaj') }}">
                            @csrf
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="name" class="col-md-4 col-form-label text-md-right offset-md-3 ">{{ __('Name') }}</label>
                                        <div class="col-md-6">
                                            <input id="name" type="text" class="form-control @error('name') is-invalid @enderror offset-md-6" name="name" value="{{ old('name') }}" required autocomplete="name" autofocus>
                                        @error('name')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                        @enderror
                                        </div>
                                        <div class="form-group">
                                            <label for="email" class="col-md-4 col-form-label text-md-right offset-md-3">{{ __('E-Mail Address') }}</label>
                                        </div>
                                    <div class="col-md-6">
                                        <input id="email" type="email" class="form-control @error('email') is-invalid @enderror offset-md-6" name="email" value="{{ old('email') }}" required autocomplete="email">

                                        @error('email')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                        @enderror
                                        </div>
                                        <div class="form-group">
                                            <label for="password" class="col-md-4 col-form-label text-md-right offset-md-3">{{ __('Password') }}</label>
                                        </div>
                                    <div class="col-md-6">
                                        <input id="password" type="password" class="form-control @error('password') is-invalid @enderror offset-md-6" name="password" required autocomplete="new-password">

                                        @error('password')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                        @enderror
                                        </div>
                                        <div class="form-group">
                                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right offset-md-3 ">{{ __('Confirm Password') }}</label>
                                        </div>
                                    
                                    <div class="col-md-6">
                                        <input id="password-confirm" type="password" class="form-control offset-md-6" name="password_confirmation" required autocomplete="new-password">
                                    </div>
                                        
                                    <div class="form-group">
                                        <select class="col-md-6 col-form-label text-md-right mt-3 offset-md-3 " name="type">
                                            <option value="registered">Registered</option>
                                            <option value="editor">Editor</option>
                                            <option value="admin">Admin</option>
                                        </select>
                                    </div>
                                    <div class="form-group row mb-0">
                                        <div class="col-md-6 offset-md-5 mt-3 mb-3">
                                            <button type="submit" class="btn btn-primary">
                                                {{ __('Confirm') }}
                                            </button>
                                        </div>
                                    </div>  
                                 </div>
                            </div>     
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
