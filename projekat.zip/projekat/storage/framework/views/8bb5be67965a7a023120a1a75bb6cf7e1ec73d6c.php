

<?php $__env->startSection('content'); ?>

<main class="mt-5 pt-4">
    <div class="container rounded bg-white mt-5 mb-5">
        <div class="row">
            <div class="col-md-3 border-right">
        
            </div>
        <div class="col-md-9 border-right">
            <div class="p-3 py-5">
                <div class="card ">
                    <div class="card-header">
                
                    <div class="row">
                        <table class="table table-striped card-table table-condensed mt-0 table-nowrap border">
                            <thead>
                                <tr>
                                    <th>Slika</th>
                                    <th>Naziv</th>
                                    <th>Kolicina</th>
                                    <th>Datum narudzbe</th>
                                    <th>Cena</th>           
                                </tr>
                            </thead>
                            <tbody>
                            <?php $total = 0; ?>
                            <?php $quantity = 0; ?>

                          
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="p-3">
            <div class="card ">
                <div class="card-header">
               
                    <table class="table table-striped card-table table-condensed mt-0 table-nowrap border">
                        <thead>
                            <tr>
                                <th>Naziv</th>
                                <th>Komentar</th>
                                <th>Datum objave</th>
                                <th>Cena</th>   
                                <th>Edit</th> 
                                <th>Delete</th>           
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $com; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td> <form action="<?php echo e(route('comments.update', $c->id)); ?>" enctype="multipart/form-data" method="POST" class="form-horizontal">
                            <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <div class="col-sm-10">
                                        <input type="text" name="comment" id="comment" class="form-control" value="<?php echo e($c->comments); ?>">
                                    </div>
                                
                            
                                <div class="form-group mt-4 text-center">
                                    <div class="col-sm-offset-2 col-sm-10">
                                        <input type="submit" class="btn btn-success" value="Update Post" />
                                    </div>
                                </div>
                            </form></td>
                                <td><?php echo e($c->created_at); ?></td>
                                <td><a href="<?php echo e(route('comments.edit', $c->id)); ?>" class="btn btn-warning">Edit</a></td>
                                <td><a href="<?php echo e(route('deleteComment', $c->id)); ?>" class="btn btn-danger" onclick="return confirm('Are you sure to delete?')">Delete</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekat\resources\views/comments.blade.php ENDPATH**/ ?>