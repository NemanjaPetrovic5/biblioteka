

<?php $__env->startSection('content'); ?>

<main class="mt-5 pt-4">
    <div class="container rounded bg-white mt-5 mb-5">
        <div class="row">
            <div class="col-md-3 border-right">
            <?php $__currentLoopData = $name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="d-flex flex-column align-items-center text-center p-3 py-5">
                    <img src="<?php echo e(asset('storage/images/profil.jpg')); ?>  " width="80%" height="250px" alt="" class="rounded-circle " width="150px">
                <span class="font-weight-bold"><?php echo e($n->name); ?></span><span class="text-black-50"><?php echo e($n->email); ?></span><span> </span></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <div class="col-md-9 border-right">
            <div class="p-3 py-5">
                <div class="card ">
                    <div class="card-header">
                    <?php $__currentLoopData = $name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h5 class="card-title"><?php echo e($n->name); ?> - Procitane knjige</h5>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <table class="table table-striped card-table table-condensed mt-0 table-nowrap border">
                            <thead>
                                <tr>
                                    <th>Slika</th>
                                    <th>Naziv</th>
                                    <th>Kolicina</th>
                                    <th>Datum narudzbe</th>
                                    <th>Cena</th>           
                                </tr>
                            </thead>
                            <tbody>
                            <?php $total = 0; ?>
                            <?php $quantity = 0; ?>

                            <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td> <img src="<?php echo e(asset('storage/uploads/' . $post->slika)); ?>  " width="50px" height="50px" alt=""> </td>
                                    <td><?php echo e($post->title); ?></td>
                                    <td><?php echo e($post->quantity); ?></td>
                                    <td><?php echo e($post->created_at); ?></td>
                                    <td><?php echo e($post->price); ?>.00 din</td>
                                </tr>
                                <?php $total = $total + ($post->cena * $post->quantity) ?>
                                <?php $quantity = $quantity + $post->quantity ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="p-3">
            <div class="card ">
                <div class="card-header">
                <?php $__currentLoopData = $name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h5 class="card-title"><?php echo e($n->name); ?> - Komentari</h5>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <table class="table table-striped card-table table-condensed mt-0 table-nowrap border">
                        <thead>
                            <tr>
                                <th>Naziv</th>
                                <th>Komentar</th>
                                <th>Edit</th> 
                                <th>Datum objave</th>
                                <th>Delete</th>           
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $com; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td> <img src="<?php echo e(asset('storage/uploads/' . $c->slika)); ?>  " width="50px" height="50px" alt=""> </td>
                                <td><?php echo e($c->title); ?></td>
                                <td> <form action="<?php echo e(route('comments.update', $c->id)); ?>" enctype="multipart/form-data" method="POST" class="form-horizontal">
                            <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <div class="col-sm-10">
                                        <textarea type="text" name="comment" id="comment" class="form-control" ><?php echo e($c->comments); ?></textarea>
                                    </div>
                                <div class="form-group mt-4 text-center">
                                    <div class="col-sm-offset-2 col-sm-10">
                                        <input type="submit" class="btn btn-success" value="Update Comment" />
                                    </div>
                                </div>
                            </form></td>
                                <td><?php echo e($c->created_at); ?></td>
                                <td><a href="<?php echo e(route('deleteComment', $c->id)); ?>" class="btn btn-danger" onclick="return confirm('Are you sure to delete?')">Delete</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekat\resources\views/profil.blade.php ENDPATH**/ ?>