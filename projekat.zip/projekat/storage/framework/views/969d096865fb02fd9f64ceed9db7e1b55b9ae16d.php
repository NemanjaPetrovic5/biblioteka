

<?php $__env->startSection('title'); ?>
    <a class="navbar-brand text-success h1" href="">
    <?php echo e('Admin-panel-Users'); ?>

    </a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('naslov'); ?>
    <h2><?php echo e('Users'); ?></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
		<div class="card-body" >
			<div class="d-lg-flex align-items-center mb-4 gap-3" >
				<div class="position-relative">
                    <form action="<?php echo e(route('home')); ?>" method="get" role="search">
                        <!-- <?php echo e(csrf_field()); ?> -->
                        <div class="input-group">
                            <input type="text" class="form-control ps-5 radius-30 mx-3" name="q" placeholder="Search Users">
                            <span class="input-group-btn">
                            <button type="submit" class="btn btn-primary">Search
                            </button>
                            </span>
                        </div>
                    </form>
				</div>
				<div class="ms-auto"><a href="<?php echo e(route('dodaj')); ?>" class="btn btn-primary radius-30 mt-2 mt-lg-0"><i class="bx bxs-plus-square"></i>Add New User</a></div>
            </div>
				<div class="table-responsive" >
					<table class="table mb-0 table table-striped card-table table-condensed table-nowrap border m-6">
						<thead class="table-light">
							<tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Type</th>
                                <th>Date created</th>
                                <th>View Details</th>
                                <th>Actions</th>
							</tr>
						</thead>
						<tbody>
						<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><div class="badge rounded-pill text-success bg-light-success p-2 text-uppercase px-3"><i class='bx bxs-circle me-1'></i><?php echo e($user->type); ?></div></td>
                                <td><?php echo e(date('d.m.Y H:i', strtotime($user->created_at))); ?></i><br/></td>
                                <td><button type="button" class="btn btn-primary btn-sm radius-30 px-4">View Details</button></td>
                                <td><a href="<?php echo e(route('users.delete', $user->id)); ?>" class="btn btn-danger" onclick="return confirm('Are you sure to delete?')">Delete</a>	
                            </tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekat\resources\views/home.blade.php ENDPATH**/ ?>