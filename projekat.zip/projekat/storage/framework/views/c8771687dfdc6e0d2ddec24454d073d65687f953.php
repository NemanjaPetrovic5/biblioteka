

<?php $__env->startSection('content'); ?>

    <div class="container-fluid bg-light py-5">
        <div class="col-md-6 m-auto text-center">
            <h1 class="h1">Contact Us</h1>
        </div>
    </div>

    <div class="container py-5">
        <div class="row py-5">
            <form class="col-md-9 m-auto" action="<?php echo e(url('poruka')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="form-group col-md-6 mb-3">
                        <label for="name">Name</label>
                        <input type="text" class="form-control mt-1" name="name" placeholder="Name">
                    </div>
                    <div class="form-group col-md-6 mb-3">
                        <label for="email">Email</label>
                        <input type="email" class="form-control mt-1"name="email" placeholder="Email">
                    </div>
                </div>
                <div class="mb-3">
                    <label for="subject">Subject</label>
                    <input type="text" class="form-control mt-1" name="subject" placeholder="Subject">
                </div>
                <div class="mb-3">
                    <label for="messages">Message</label>
                    <textarea class="form-control mt-1" name="messages" placeholder="Message" rows="8"></textarea>
                </div>
                <div class="row">
                    <div class="col text-end mt-2">
                        <button type="submit" class="btn btn-success btn-lg px-3">Send message</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <!-- Mapa -->
    <div id="mapid" style="width: 100%; height: 300px;"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2830.233790485527!2d20.45594851640576!3d44.81680157909864!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x475a7b303e236421%3A0xc1edd5324b97a588!2sKnez%20Mihailova!5e0!3m2!1sen!2srs!4v1623710524524!5m2!1sen!2srs" width="100%" height="350" style="border:0;" allowfullscreen="" loading="lazy"></iframe></div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nemanja\Desktop\projekat\resources\views/contact.blade.php ENDPATH**/ ?>