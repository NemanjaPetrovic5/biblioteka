
<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
     <title>Admin-panel</title>
</head>

<body style=" font-family: Arial, Helvetica, sans-serif;
background-color: #f1f1f1;
position: relative;
padding-bottom: 58px;
min-height: 100vh;
">
    <div id="app">
        <nav class="navbar navbar-expand-lg navbar-light shadow">
            <div class="container-fluid">
            <?php echo $__env->yieldContent('title'); ?>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="<?php echo e(route('admin-panel')); ?>">Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="<?php echo e(route('admin-posts')); ?>">Postovi</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="<?php echo e(route('admin-orders')); ?>">Narudbine</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="<?php echo e(route('admin-users')); ?>">Users</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="<?php echo e(route('admin-messages')); ?>">Messages</a>
                        </li>
                    </ul>
                </div>
                <div class="d-flex">
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                
                    <a class="d-flex align-items-center nav-link dropdown-toggle dropdown-toggle-nocaret" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <div class="user-info ps-3">
							<?php $__currentLoopData = $name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="text-dark h4"><?php echo e($n->name); ?></p>
                                <p class="text-dark h6 ms-6"><?php echo e($n->type); ?></p>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="<?php echo e(route('admin-panel')); ?>">Dashboard</a>
                            </li>
                            <li><a class="dropdown-item" href="<?php echo e(route('admin-posts')); ?>">Postovi</a>
                            </li>
                            <li><a class="dropdown-item" href="<?php echo e(route('admin-orders')); ?>">Narudzbine</a>
                            </li>
                            <li>
                                <div class="dropdown-divider mb-0"></div>
                            </li>
                            <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>            
    <div class="page-wrapper mt-4" style="margin-left:100px;margin-right:100px;">
        <div class="page-content">
            <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
                <?php echo $__env->yieldContent('naslov'); ?>
            </div>

    <main style="margin-bottom:50px;">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <footer style="text-align: center;
      background-color: #333;
      color: #fff;
      margin-left:-100px;
      padding: 20px;
      position: absolute;
      bottom: 0;
      width: 100%;">
        <p>Copyright &copy; <script>document.write(new Date().getFullYear());</script>, Nemanja Petrović</p>
      </footer>

    </body>
</html><?php /**PATH C:\xampp\htdocs\projekat\resources\views/layouts/app-admin.blade.php ENDPATH**/ ?>