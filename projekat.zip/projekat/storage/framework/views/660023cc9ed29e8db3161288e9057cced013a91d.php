

<?php $__env->startSection('title'); ?>
    <a class="navbar-brand text-success h1" href="">
    <?php echo e('Admin-panel-Comments'); ?>

    </a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('naslov'); ?>
    <h2><?php echo e('Comments'); ?></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="card">
		<div class="card-body">
			<div class="d-lg-flex align-items-center mb-4 gap-3">
			</div>
			<div class="table-responsive">
				<table class="table mb-0 table table-striped card-table table-condensed table-nowrap border">
                    <thead class="table-light">
                        <tr>
                            <th>Title</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Comment</th>
                            <th>Date created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
					<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($comment->title); ?></td>
                            <td><?php echo e($comment->name); ?></td>
                            <td><?php echo e($comment->email); ?></td>
                            <td><?php echo e($comment->comments); ?></td>
                            <td><?php echo e(date('d.m.Y H:i', strtotime($comment->created_at))); ?></i><br/></td>
                            <td><a href="<?php echo e(route('admin-comments.delete', $comment->id)); ?>" class="btn btn-danger" onclick="return confirm('Are you sure to delete?')">Delete</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
				</table>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekat\resources\views/admin-comments.blade.php ENDPATH**/ ?>