

<?php $__env->startSection('content'); ?>
  <main>
    <div class="container">
      <nav class="navbar navbar-expand-lg mt-3 mb-5">
      
       
        <form action="<?php echo e(route('posts.index')); ?>" method="get" role="search">
          <!-- <?php echo e(csrf_field()); ?> -->
          <div class="input-group">
            <input type="text" class="form-control" style="width:300px;height:50px;margin-right:5px;"name="q" placeholder="Search">
            <span class="input-group-btn">
            <button type="submit" style="height:50px" class="btn btn-primary">Search
            </button>
            </span>
          </div>
        </form>
      </nav>
    <div class="container">
      <div class="row">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-lg-3 col-md-6 mb-4">
              <div class="card h-100">
              <a href="<?php echo e(route('posts.details', $post->id)); ?>">
                <img src="<?php echo e(asset('storage/uploads/' . $post->slika)); ?>  " width="100%" height="250px" alt="">
              </a>
              <div class="card">
                  <div class="card-body ml-6">
                      <h3 class="card-title ms-5"><a class="text-decoration-none" href="<?php echo e(route('posts.details', $post->id)); ?>"><?php echo e($post->title); ?></a></h3>
                      <h5 style="margin-left:60px">Cena: <?php echo e($post->cena); ?>.00 din</h5>
                  </div>
                  <div class="mb-3">
                  <a href="<?php echo e(route('posts.details', $post->id)); ?>" class="btn btn-success col-md-6 col-6 col-form-label  mt-3 offset-md-3 offset-3">Details</a>
              </div>
              </div>
              </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <!--Pagination-->
      <nav class="d-flex justify-content-center wow fadeIn">
        <ul class="pagination pg-blue">
        <?php echo $posts->appends(Request::all())->links(); ?>

        </ul>
        </nav>
    </div>
  </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekat\resources\views/posts/index.blade.php ENDPATH**/ ?>