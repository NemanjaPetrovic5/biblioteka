

<?php $__env->startSection('title'); ?>
    <a class="navbar-brand text-success h1" href="">
    <?php echo e('Admin-panel-Categories'); ?>

    </a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('naslov'); ?>
    <h2><?php echo e('Categories'); ?></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="card">
    <div class="ms-auto"><a href="<?php echo e(route('add-category')); ?>" class="btn btn-primary radius-30 mt-2 mt-lg-0"><i class="bx bxs-plus-square"></i>Add New Post</a></div>
		<div class="card-body">
			<div class="d-lg-flex align-items-center mb-4 gap-3">
			</div>
			<div class="table-responsive">
				<table class="table mb-0 table table-striped card-table table-condensed table-nowrap border">
                    <thead class="table-light">
                        <tr>
                            <th>Name</th>
                            <th>Date created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
					<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($c->name); ?></td>
                            <td><?php echo e(date('d.m.Y H:i', strtotime($c->created_at))); ?></i><br/></td>
                            <td><a href="<?php echo e(route('admin-comments.delete', $comment->id)); ?>" class="btn btn-danger" onclick="return confirm('Are you sure to delete?')">Delete</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
				</table>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekat\resources\views/posts-category.blade.php ENDPATH**/ ?>