

<?php $__env->startSection('title'); ?>
    <a class="navbar-brand text-success h1" href="">
    <?php echo e('Admin-panel-Dashboard'); ?>

    </a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('naslov'); ?>
    <h2><?php echo e('Dashboard'); ?></h2>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php  
 $connect = mysqli_connect("localhost", "root", "", "projekat");  
 $query = "SELECT category, count(*) as number FROM posts INNER JOIN orders WHERE posts.id=orders.posts_id GROUP BY category";  
 $result = mysqli_query($connect, $query);  
 ?>  
 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>Najprodavanija kategorija</title>  
           <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>  
           <script type="text/javascript">  
           google.charts.load('current', {'packages':['corechart']});  
           google.charts.setOnLoadCallback(drawChart);  
           function drawChart()  
           {  
                var data = google.visualization.arrayToDataTable([  
                          ['Gender', 'Number'],  
                          <?php  
                          while($row = mysqli_fetch_array($result))  
                          {  
                               echo "['".$row["category"]."', ".$row["number"]."],";  
                          }  
                          ?>  
                     ]);  
                var options = {  
                      title: 'Procenat po narudzbini',  
                      //is3D:true,  
                      pieHole: 0.4  
                     };  
            
                var chart = new google.visualization.PieChart(document.getElementById('piechart'));  
                chart.draw(data, options);  

           }  
           </script>  
           
      </head>  
      <body>  
      <div class="container-fluid bg-light py-5">
          <div class="container">
               <br /><br />  
               
               <div class="table-light">  
                    <h3>Najprodavanije kategorije proizvoda</h3>  
                    <br />  
                    <div id="piechart" style="width: 700px; height: 500px;"></div>  
               </div> 
               
          </div>
     </body>  
 </html>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekat\resources\views/admin-panel.blade.php ENDPATH**/ ?>