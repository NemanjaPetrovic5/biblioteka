

<?php $__env->startSection('content'); ?>
    <main class="mt-5 pt-4 mb-5">
        <div class="container">
            <div class="card ">
                <div class="card-header">
                    <h5 class="card-title">Korpa</h5>
                <div class="row">
                <?php if(Session::has('error_message')): ?>
                            <div class="alert alert-danger">
                              <?php echo e(Session::get('error_message')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php endif; ?>
                        <?php if(Session::has('success_message')): ?>
                            <div class="alert alert-success">
                                <?php echo e(Session::get('success_message')); ?>

                            </div>
                        <?php endif; ?>
                    <table class="table table-striped card-table table-condensed mt-0 table-nowrap border">
                        <thead>
                            <tr>
                                <th>Slika</th>
                                <th>Ime</th>
                                <th>Naziv proizvoda</th>
                                <th>Količina</th>
                                <th>Dodato u korpu</th>
                                <th>Cena</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $total = 0; ?>
                        <?php $quantity = 0; ?>
                        <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td> <img src="<?php echo e(asset('storage/uploads/' . $post->slika)); ?>  " width="50px" height="50px" alt=""></td>
                                <td><?php echo e($post->name); ?></td>
                                <td><?php echo e($post->title); ?></td>
                                <td><input name="quantity" type="number"  class="span1" placeholder="<?php echo e($post->quantity); ?>"  style="width: 50px " required></td>
                                <td><?php echo e($post->created_at); ?></td>
                                <td><?php echo e($post->cena); ?>.00 din</td>
                                <td><a href="<?php echo e(route('cart.delete', $post->id)); ?>" class="btn btn-danger" onclick="return confirm('Are you sure to delete?')">Delete</a></td>
                            
                            </tr>
                            <?php $total = $total + ($post->cena * $post->quantity) ?>
                            <?php $quantity = $quantity + $post->quantity ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td colspan=12 style="text-align: right">Ukupno za placanje:  <?php echo e($total); ?>.00 din</td>
                        </tbody>
                    </table>
                    <?php if(!empty($post->posts_id)): ?>
                    <form colspan=12 style="text-align: right" action="<?php echo e(url('naruci')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                    
                        <input type="hidden" name="posts_id" value="<?php echo e($post->posts_id); ?>">
                        <input type="hidden" name="quantity" value="<?php echo e($quantity); ?>">
                        <input type="hidden" name="price" value="<?php echo e($total); ?>">
                        <input type="hidden" name="stanje" value="na cekanju">

                        <button class="btn btn-primary btn-md my-0 p" type="submit">Naruci
                            <i class="fas fa-shopping-cart ml-1"></i>
                        </button>
                    </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nemanja\Desktop\projekat\resources\views/posts/cart.blade.php ENDPATH**/ ?>