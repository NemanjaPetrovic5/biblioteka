

<?php $__env->startSection('title'); ?>
    <a class="navbar-brand text-success h1" href="">
    <?php echo e('Admin-panel-Add Category'); ?>

    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="page-wrapper">
			<div class="page-content">
				<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
					<div class="breadcrumb-title pe-3 h3">Add new category</div>
                </div>
			</div>
			<div class="card">
				<div class="card-body">
					<div class="d-lg-flex align-items-center">
						<div class="ms-auto"><a href="<?php echo e(route('admin-posts')); ?>" class="btn btn-primary radius-30 mt-2 mt-lg-0"><i class="bx bxs-plus-square"></i>Back</a></div>
					</div>
					<div class="table-responsive">
                        <div class="card-body">
                            <form method="POST" enctype="multipart/form-data" id="upload-image" action="<?php echo e(url('add')); ?>" >
                            <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="control-label col-sm-2 " >Title</label>
                                            <div class="col-sm-10">
                                                <input type="text" name="name" id="name" class="form-control">
                                            </div>
                                        </div>
                                        
                                    <div class="col-md-12">
                                        <button type="submit" class="btn btn-primary mt-3" id="submit">Submit</button>
                                    </div>
                                </div>     
                            </form>
                        </div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekat\resources\views/posts-addcategory.blade.php ENDPATH**/ ?>