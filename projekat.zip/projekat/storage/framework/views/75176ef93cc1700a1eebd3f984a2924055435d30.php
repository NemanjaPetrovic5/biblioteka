<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Knjizara')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
    <!-- <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script> -->
    
</head>
<body style=" font-family: Arial, Helvetica, sans-serif;
background-color: #f1f1f1;
position: relative;
padding-bottom: 58px;
min-height: 100vh;
">

    <nav class="navbar navbar-expand-lg navbar-light d-none d-lg-block" style="background-color: #333;">
        <div class="container text-light">
            <div class="w-100 d-flex justify-content-between">
                <div>
                    <a class="text-light text-decoration-none" href="#">knjizara@knjizara.com</a>
                    <a class="text-light text-decoration-none" href="#">010-020-0340</a>
                </div>
                
            </div>
        </div>
    </nav>
    <div id="app">
        <nav class="navbar navbar-expand-lg navbar-light shadow">
        <div class="container">
            <a class="navbar-brand text-success h1" href="<?php echo e(url('/')); ?>"><?php echo e('Knjižara'); ?></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="<?php echo e(route('posts.index')); ?>">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="<?php echo e(route('about')); ?>">About</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="<?php echo e(route('contact')); ?>">Contact</a>
                        </li> 
                    </div>
                    <div class="d-flex">
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="nav navbar-nav">
     
                    <?php if(auth()->guard()->check()): ?>
                        <li class="nav-item active">
                            <a class="nav-link text-dark" href="<?php echo e(route('cart')); ?>">Cart</a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link text-dark" href="<?php echo e(route('orders')); ?>">Orders</a>
                        </li>
                    <?php endif; ?>
                    <?php if(auth()->guard()->guest()): ?>
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                        </li>
                    <?php if(Route::has('register')): ?>
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                        </li>
                    <?php endif; ?>
                    <?php else: ?>
                    <div class="dropdown">
                            <button class="btn btn-primary dropdown-toggle nav-link dropdown-toggle text-white" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php echo e(Auth::user()->name); ?>

                            </button>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                            <li class="dropdown-item"><a class="nav-link text-dark" href="<?php echo e(route('profil')); ?>"><?php echo e(__('Profil')); ?></a></li>
                            <li class="dropdown-item">
                                <a class="nav-link text-dark" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                     </div>
                </div>
            </div>
        </div>
    </nav>

    <main style="margin-bottom:50px;">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <footer style="text-align: center;
      background-color: #333;
      color: #fff;
      padding: 20px;
      position: absolute;
      bottom: 0;
      width: 100%;">
        <p>Copyright &copy; <script>document.write(new Date().getFullYear());</script>, Nemanja Petrović</p>
      </footer>
</body>
</html><?php /**PATH C:\xampp\htdocs\projekat\resources\views/layouts/app.blade.php ENDPATH**/ ?>